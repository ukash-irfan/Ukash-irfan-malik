
package inheritance;

public class  Dog extends Animal {
        void barking(){
            System.out.println("barking....");
        }

}
