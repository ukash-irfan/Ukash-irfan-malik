package inheritance;
public class Inheritance {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.barking();
        d.eat();
        d.sleep();
        Animal a= new Animal();
        a.eat();
        a.sleep();
    }
    
}
